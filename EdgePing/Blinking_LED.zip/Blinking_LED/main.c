#include "cy_pdl.h"
#include "cyhal.h"
#include "cybsp.h"

// Defines what each port the LEDs are connected to
#define RED_LED_PORT GPIO_PRT9
#define GREEN_LED_PORT GPIO_PRT9
//Defines what pin is each LED connected to
#define RED_LED 0U
#define GREEN_LED 3U

int main(void)
{

    cy_rslt_t result = cybsp_init();

    __enable_irq();


    if (result != CY_RSLT_SUCCESS)
    {
        CY_ASSERT(0);
    }

//Defines the pins as outputs
    Cy_GPIO_Pin_FastInit(RED_LED_PORT, RED_LED, CY_GPIO_DM_STRONG, 1UL, HSIOM_SEL_GPIO);
    Cy_GPIO_Pin_FastInit(GREEN_LED_PORT, GREEN_LED, CY_GPIO_DM_STRONG, 1UL, HSIOM_SEL_GPIO);

//Make LEDs blink back and forth 1000ms at a time
    while (1)
    {
    	Cy_GPIO_Write(RED_LED_PORT, RED_LED, CYBSP_LED_STATE_ON);
    	Cy_GPIO_Write(GREEN_LED_PORT, GREEN_LED, CYBSP_LED_STATE_OFF);
    	Cy_SysLib_Delay(1000);
    	Cy_GPIO_Write(RED_LED_PORT, RED_LED, CYBSP_LED_STATE_OFF);
    	Cy_GPIO_Write(GREEN_LED_PORT, GREEN_LED, CYBSP_LED_STATE_ON);
    	Cy_SysLib_Delay(1000);
    }
}
