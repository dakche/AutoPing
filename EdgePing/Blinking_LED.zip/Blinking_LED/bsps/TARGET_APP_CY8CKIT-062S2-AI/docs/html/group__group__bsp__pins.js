var group__group__bsp__pins =
[
    [ "LED Pins", "group__group__bsp__pins__led.html", "group__group__bsp__pins__led" ],
    [ "Button Pins", "group__group__bsp__pins__btn.html", "group__group__bsp__pins__btn" ],
    [ "Communication Pins", "group__group__bsp__pins__comm.html", "group__group__bsp__pins__comm" ],
    [ "WCO", "group__group__bsp__pins__wco.html", "group__group__bsp__pins__wco" ]
];